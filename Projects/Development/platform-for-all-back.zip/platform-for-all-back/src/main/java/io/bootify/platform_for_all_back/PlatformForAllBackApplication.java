package io.bootify.platform_for_all_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class PlatformForAllBackApplication {

    public static void main(final String[] args) {
        SpringApplication.run(PlatformForAllBackApplication.class, args);
    }

}
